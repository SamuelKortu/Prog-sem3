# 📚 Limkokwing Library API Simulation

**Module:** PROG315 — Object-Oriented Programming 2  
**Assignment:** Basic API Structure with Open-Source Software  
**Part:** B — Implementation  
**Semester:** 04 | March 2026 – July 2026  
**Institution:** Limkokwing University of Creative Technology, Sierra Leone  

---

## 📌 Project Description

This project simulates a basic digital library management API for Limkokwing University's library system. It is built entirely using **Python's built-in `asyncio` library** — no external web frameworks (FastAPI, Flask, Django) are used.

The simulation demonstrates how multiple users can interact with the library system **at the same time** using asynchronous programming (`async` / `await` / `asyncio.gather()`).

---

## ⚙️ Features

| Endpoint (Simulated)        | Function            | Description                                         |
|-----------------------------|---------------------|-----------------------------------------------------|
| `GET /books`                | `search_books()`    | Search for books by title, author, or category      |
| `POST /borrow`              | `borrow_book()`     | Borrow an available book for 14 days                |
| `POST /return`              | `return_book()`     | Return a borrowed book and calculate overdue fines  |
| `GET /fines/{user_id}`      | `check_fines()`     | Check outstanding overdue fine without returning    |

---

## 🗂️ Project Structure

```
limkokwing-library-api/
│
├── library_api.py      # Main simulation script (all async logic)
├── README.md           # Project documentation
└── .gitignore          # Files excluded from version control
```

---

## 🚀 How to Run

### Requirements
- Python 3.10 or higher (no external packages needed)

### Steps

```bash
# 1. Clone the repository
git clone https://github.com/your-username/limkokwing-library-api.git

# 2. Navigate into the project folder
cd limkokwing-library-api

# 3. Run the simulation
python library_api.py
```

---

## 🔍 What the Simulation Does

The script runs **3 rounds** of concurrent user activity:

- **Round 1** — Four users act simultaneously: one searches, two borrow different books, one checks their overdue fine
- **Round 2** — A user returns a book, another attempts a conflicting borrow, an overdue book is returned with a fine applied
- **Round 3** — A user attempts a borrow after successfully returning their previous book

All requests in each round run **concurrently** via `asyncio.gather()`, simulating real-world simultaneous access.

---

## 🧠 Concepts Demonstrated

- `async def` functions for non-blocking endpoint simulation
- `await asyncio.sleep()` to simulate network/database latency
- `asyncio.gather()` to run multiple coroutines concurrently
- Type annotations (`str`, `dict`, `float`, `Optional`, `list`)
- In-memory data store using Python dictionaries
- Business logic: availability checks, overdue fine calculation ($0.50/day)

---

## 📄 License

This project is submitted as academic coursework for PROG315 at Limkokwing University of Creative Technology, Sierra Leone. Not intended for commercial use.
