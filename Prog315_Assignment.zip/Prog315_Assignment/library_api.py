import asyncio
import random
from datetime import datetime, timedelta
from typing import Optional


# ─────────────────────────────────────────────
# DATA STORE (in-memory)
# ─────────────────────────────────────────────

BOOKS: dict[str, dict] = {
    "B001": {"title": "Clean Code",          "author": "Robert Martin",  "category": "Programming", "available": True},
    "B002": {"title": "The Pragmatic Programmer", "author": "Andrew Hunt", "category": "Programming", "available": True},
    "B003": {"title": "Introduction to Algorithms", "author": "Cormen",  "category": "Computer Science", "available": True},
    "B004": {"title": "Design Patterns",     "author": "Gang of Four",   "category": "Software Engineering", "available": False},
    "B005": {"title": "Atomic Habits",       "author": "James Clear",    "category": "Self-Help",   "available": True},
}

# Stores active borrows: { user_id: { book_id, borrow_date, due_date } }
BORROWS: dict[str, dict] = {
    "U003": {
        "book_id": "B004",
        "borrow_date": datetime.now() - timedelta(days=20),
        "due_date":    datetime.now() - timedelta(days=6),   # already overdue
    }
}

FINE_PER_DAY: float = 0.50   # USD per overdue day


# ─────────────────────────────────────────────
# ENDPOINT 1 — Search Books
# ─────────────────────────────────────────────

async def search_books(query: str, field: str = "title") -> dict:
    """
    Simulates: GET /books?query=...&field=...
    Searches the in-memory book store by title, author, or category.
    Returns a list of matching books.
    """
    await asyncio.sleep(0.3)   # simulate network / DB latency

    field = field.lower()
    results: list[dict] = []

    for book_id, info in BOOKS.items():
        value: str = str(info.get(field, "")).lower()
        if query.lower() in value:
            results.append({"book_id": book_id, **info})

    if results:
        return {"status": "success", "count": len(results), "books": results}
    return {"status": "not_found", "message": f"No books matched '{query}' in field '{field}'."}


# ─────────────────────────────────────────────
# ENDPOINT 2 — Borrow a Book
# ─────────────────────────────────────────────

async def borrow_book(user_id: str, book_id: str) -> dict:
    """
    Simulates: POST /borrow
    Allows a user to borrow an available book for 14 days.
    Rejects if the book is unavailable or user already has an active borrow.
    """
    await asyncio.sleep(0.5)   # simulate DB write latency

    if user_id in BORROWS:
        active: str = BORROWS[user_id]["book_id"]
        return {
            "status": "error",
            "message": f"User {user_id} already has book {active} borrowed. Return it first."
        }

    if book_id not in BOOKS:
        return {"status": "error", "message": f"Book {book_id} does not exist."}

    if not BOOKS[book_id]["available"]:
        return {"status": "error", "message": f"Book {book_id} is currently unavailable."}

    # Mark as borrowed
    BOOKS[book_id]["available"] = False
    borrow_date: datetime = datetime.now()
    due_date: datetime    = borrow_date + timedelta(days=14)

    BORROWS[user_id] = {
        "book_id":    book_id,
        "borrow_date": borrow_date,
        "due_date":    due_date,
    }

    return {
        "status":      "success",
        "message":     f"User {user_id} successfully borrowed '{BOOKS[book_id]['title']}'.",
        "due_date":    due_date.strftime("%Y-%m-%d"),
    }


# ─────────────────────────────────────────────
# ENDPOINT 3 — Return a Book
# ─────────────────────────────────────────────

async def return_book(user_id: str) -> dict:
    """
    Simulates: POST /return
    Processes the return of a borrowed book.
    Calculates any overdue fine if the due date has passed.
    """
    await asyncio.sleep(0.4)   # simulate processing delay

    if user_id not in BORROWS:
        return {"status": "error", "message": f"No active borrow record found for user {user_id}."}

    record:    dict     = BORROWS.pop(user_id)
    book_id:   str      = record["book_id"]
    due_date:  datetime = record["due_date"]
    today:     datetime = datetime.now()

    BOOKS[book_id]["available"] = True   # make book available again

    fine: float = 0.0
    overdue_days: int = (today - due_date).days
    if overdue_days > 0:
        fine = round(overdue_days * FINE_PER_DAY, 2)

    return {
        "status":       "success",
        "message":      f"Book '{BOOKS[book_id]['title']}' returned by user {user_id}.",
        "overdue_days": max(overdue_days, 0),
        "fine_usd":     fine,
    }


# ─────────────────────────────────────────────
# ENDPOINT 4 — Check Overdue Fines
# ─────────────────────────────────────────────

async def check_fines(user_id: str) -> dict:
    """
    Simulates: GET /fines/{user_id}
    Returns the current overdue fine for a user without returning the book.
    Returns zero if book is still within the due date.
    """
    await asyncio.sleep(0.2)

    if user_id not in BORROWS:
        return {"status": "no_borrow", "message": f"User {user_id} has no active borrows."}

    record:    dict     = BORROWS[user_id]
    due_date:  datetime = record["due_date"]
    today:     datetime = datetime.now()
    overdue_days: int   = (today - due_date).days

    fine: float = round(max(overdue_days, 0) * FINE_PER_DAY, 2)

    return {
        "status":       "success",
        "user_id":      user_id,
        "book_id":      record["book_id"],
        "due_date":     due_date.strftime("%Y-%m-%d"),
        "overdue_days": max(overdue_days, 0),
        "fine_usd":     fine,
    }


# ─────────────────────────────────────────────
# HELPER — Pretty Print Results
# ─────────────────────────────────────────────

def display(label: str, result: dict) -> None:
    print(f"\n{'─'*55}")
    print(f"  {label}")
    print(f"{'─'*55}")
    for key, value in result.items():
        if key == "books":
            print(f"  {key}:")
            for b in value:
                print(f"      • [{b['book_id']}] {b['title']} — {b['author']} ({b['category']}) | Available: {b['available']}")
        else:
            print(f"  {key:15}: {value}")


# ─────────────────────────────────────────────
# SIMULATION — Multiple Concurrent Users
# ─────────────────────────────────────────────

async def simulate_multiple_users() -> None:
    """
    Runs multiple user actions concurrently using asyncio.gather().
    Demonstrates how the system handles simultaneous requests.
    """
    print("\n" + "═"*55)
    print("  LIMKOKWING LIBRARY API — CONCURRENT USER SIMULATION")
    print("═"*55)

    # ── Round 1: All users act at the same time ──
    print("\n[ROUND 1] Three users sending requests simultaneously...\n")

    results = await asyncio.gather(
        search_books("Programming", field="category"),   # User A searches
        borrow_book("U001", "B001"),                     # User B borrows Clean Code
        borrow_book("U002", "B003"),                     # User C borrows Algorithms
        check_fines("U003"),                             # User D checks their fine (overdue)
    )

    labels = [
        "User A — Search by Category: 'Programming'",
        "User B — Borrow Book B001 (Clean Code)",
        "User C — Borrow Book B003 (Algorithms)",
        "User D — Check Overdue Fine",
    ]

    for label, result in zip(labels, results):
        display(label, result)

    # ── Round 2: Returns and edge cases ──
    print("\n\n[ROUND 2] Returns and conflict handling...\n")

    results2 = await asyncio.gather(
        return_book("U001"),                             # User B returns their book
        borrow_book("U001", "B002"),                     # User B tries to borrow again before returning (should fail if not returned yet)
        search_books("James Clear", field="author"),     # Search by author
        return_book("U003"),                             # Overdue return — fine applied
    )

    labels2 = [
        "User B — Return Book B001",
        "User B — Attempt to Borrow B002 (conflict test)",
        "User E — Search Author: 'James Clear'",
        "User D — Return Overdue Book (fine applied)",
    ]

    for label, result in zip(labels2, results2):
        display(label, result)

    # ── Round 3: Post-return borrow ──
    print("\n\n[ROUND 3] After returns — new borrow attempt...\n")

    result3 = await borrow_book("U001", "B002")
    display("User B — Borrow B002 after returning B001", result3)

    print("\n\n" + "═"*55)
    print("  SIMULATION COMPLETE")
    print("═"*55 + "\n")


# ─────────────────────────────────────────────
# ENTRY POINT
# ─────────────────────────────────────────────

if __name__ == "__main__":
    asyncio.run(simulate_multiple_users())
